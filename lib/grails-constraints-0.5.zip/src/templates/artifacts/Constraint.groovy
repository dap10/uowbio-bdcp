@artifact.package@

class @artifact.name@ {

    def validate = { propertyValue ->
        // execute validation
    }
}
